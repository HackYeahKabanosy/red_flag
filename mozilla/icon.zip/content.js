function extractText() {
    return document.body.innerText || "";
  }
  
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "getTextContent") {
      const textContent = extractText();
      sendResponse({ content: textContent });
    }
  });
  